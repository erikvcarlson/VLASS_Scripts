__rethrow_casa_exceptions = True
context = h_init()
context.set_state('ProjectSummary', 'proposal_code', 'VLASS')
context.set_state('ProjectSummary', 'proposal_title', 'unknown')
context.set_state('ProjectSummary', 'piname', 'unknown')
context.set_state('ProjectSummary', 'observatory', 'Karl G. Jansky Very Large Array')
context.set_state('ProjectSummary', 'telescope', 'EVLA')
context.set_state('ProjectStructure', 'ppr_file', 'PPR.xml')
context.set_state('ProjectStructure', 'recipe_name', 'hifv_vlassSEIP')
try:
    hifv_importdata(ocorr_mode='co', createmms='automatic', nocopy=True, overwrite=False, asis='Receiver CalAtmosphere', session=['session_1'], vis=['transformed_tt_1000.ms'])
    hif_editimlist(nsigma=-999.0, sensitivity=0.0, scales=array([], dtype=float64), robust=-999.0, pblimit=-999.0, parameter_file='SEIP_parameter.list', nterms=0, niter=0, nchan=-1, nbin=-1, pbmask=0.0, imsize=array([], dtype=float64), cycleniter=-999, cyclefactor=-999.0, conjbeams=False, search_radius_arcsec=1000.0)
    hif_makeimages(parallel='automatic', overwrite_on_export=True, mosweight=False, calcsb=False, cleancontranges=False, masklimit=4, clearlist=True, tlimit=2.0, hm_maxpsffraction=-999.0, hm_minpsffraction=-999.0, hm_cyclefactor=-999.0, hm_npixels=0, hm_perchanweightdensity=False, hm_nsigma=0.0, hm_fastnoise=True, hm_minpercentchange=-999.0, hm_dogrowprune=True, hm_growiterations=-999, hm_minbeamfrac=-999.0, hm_negativethreshold=-999.0, hm_lownoisethreshold=-999.0, hm_noisethreshold=-999.0, hm_sidelobethreshold=-999.0, hm_masking='manual')
    hif_editimlist(nsigma=-999.0, sensitivity=0.0, scales=array([], dtype=float64), robust=-999.0, pblimit=-999.0, parameter_file='SEIP_parameter.list', nterms=0, niter=0, nchan=-1, nbin=-1, pbmask=0.0, imsize=array([], dtype=float64), cycleniter=-999, cyclefactor=-999.0, conjbeams=False, search_radius_arcsec=1000.0)
    hif_makeimages(parallel='automatic', overwrite_on_export=True, mosweight=False, calcsb=False, cleancontranges=False, masklimit=4, clearlist=True, tlimit=2.0, hm_maxpsffraction=-999.0, hm_minpsffraction=-999.0, hm_cyclefactor=-999.0, hm_npixels=0, hm_perchanweightdensity=False, hm_nsigma=0.0, hm_fastnoise=True, hm_minpercentchange=-999.0, hm_dogrowprune=True, hm_growiterations=-999, hm_minbeamfrac=-999.0, hm_negativethreshold=-999.0, hm_lownoisethreshold=-999.0, hm_noisethreshold=-999.0, hm_sidelobethreshold=-999.0, hm_masking='manual')
    hif_editimlist(nsigma=-999.0, sensitivity=0.0, scales=array([], dtype=float64), robust=-999.0, pblimit=-999.0, parameter_file='SEIP_parameter.list', nterms=0, niter=0, nchan=-1, nbin=-1, pbmask=0.0, imsize=array([], dtype=float64), cycleniter=-999, cyclefactor=-999.0, conjbeams=False, search_radius_arcsec=1000.0)
    hif_makeimages(parallel='automatic', overwrite_on_export=True, mosweight=False, calcsb=False, cleancontranges=False, masklimit=4, clearlist=True, tlimit=2.0, hm_maxpsffraction=-999.0, hm_minpsffraction=-999.0, hm_cyclefactor=-999.0, hm_npixels=0, hm_perchanweightdensity=False, hm_nsigma=0.0, hm_fastnoise=True, hm_minpercentchange=-999.0, hm_dogrowprune=True, hm_growiterations=-999, hm_minbeamfrac=-999.0, hm_negativethreshold=-999.0, hm_lownoisethreshold=-999.0, hm_noisethreshold=-999.0, hm_sidelobethreshold=-999.0, hm_masking='manual')
finally:
    h_save()
